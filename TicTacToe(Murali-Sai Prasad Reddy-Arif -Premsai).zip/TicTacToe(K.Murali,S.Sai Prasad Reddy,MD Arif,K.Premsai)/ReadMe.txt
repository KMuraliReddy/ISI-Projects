#TiCTacToe
This project allows user to play tictactoe game.Whenever there is a winner it will display the winner and resets to new board.The available board sizes are 3*3,4*4 and 5*5.
user can select Modes from below:
**user Vs user
**user vs AI

AI working process:
** It will first check that with the next MOVE CAN OPPOSITE PLAYER WIN THE GAME.
if yes, it will block that place by placing its value;
if not,
** It will check that with the next move can computer win the game.
if yes, it will put the value of computer.Then it will declare a winner.
if not,
** It will try to block the corner if available.if not,
** It will call randomGeneration method with will try to find an empty slot in the board using Math.Random class.


*** WE HAVE TRIED TO DO WITH OUR OWN KNOWLEDGE WITH OUT ANY REFERENCES AND HELP.
Thank you
