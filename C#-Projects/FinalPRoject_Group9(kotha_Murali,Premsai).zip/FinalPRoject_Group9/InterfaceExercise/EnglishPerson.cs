﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExercise
{
    class EnglishPerson : Human
    {
        public override void Talk()
        {
            Console.WriteLine("English PErson Might Say ..Hey How Are You");        }
    }
}
