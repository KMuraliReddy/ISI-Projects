﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceExercise
{
    class IndianPerson :Human
    {
        public override void Talk()
        {
            Console.WriteLine("Well  You Cant Decide An Indian Dialouge!!!!");        }
    }
}
