﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PhoneBookApp
{
    static class PhoneBook
    {
        public static List<PhoneBookListing> Listings = new List<PhoneBookListing>()
        {

        new PhoneBookListing("Kotha","Murali","8500879858"),
        new PhoneBookListing("Kotha","Mukesh","9618128328"),
        new PhoneBookListing("Sandhi","Madhu","8978581147"),
        new PhoneBookListing("Kotha","Murali","5149236055"),
        new PhoneBookListing("Sandhi","janaki","8125563671"),
        new PhoneBookListing("Sachin","Tendulkar","1234568079"),
        new PhoneBookListing("Virender","sehwag","5869430526"),
        new PhoneBookListing("donalnd","trumpah","5414346313")
    };

            }
}
