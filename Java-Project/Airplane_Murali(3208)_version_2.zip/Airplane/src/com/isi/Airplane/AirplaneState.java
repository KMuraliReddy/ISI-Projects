package com.isi.Airplane;

public enum AirplaneState {

	OFF,RUNNING,FLYING;
}
