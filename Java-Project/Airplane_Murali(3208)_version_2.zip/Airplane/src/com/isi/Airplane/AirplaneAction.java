package com.isi.Airplane;

public enum AirplaneAction {

	START,STOP,TAKEOFF,INCREASEALTITUDE,DECREASEALTITUDE,LAND;

}
