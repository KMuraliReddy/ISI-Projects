package com.isi.java.practical.model;

import com.isi.java.practical.view.ICarView;

public class Car implements ICarModel, Runnable
{	
	// Static constants
	
	public static final double minCapacity = 35;
	public static final double maxCapacity = 95;
	public static final double drivingDelta = -2.3d;
	public static final double fillingDelta = 3.6d;
	
	
	// Instance variables
	
	private double gasLevel;
	private double gasCapacity;
	private GasLevelState gasLevelState;
	private CarState carState;

	private ICarView view;
	private ICarView client;
	

	// Getter methods
	// Implementation of ICarModel interface
	
	@Override
	public double getGasLevel() { return 0; }
	@Override
	public double getGasCapacity() { return 0; }
	@Override
	public GasLevelState getGasLevelState() { return null; }
	@Override
	public CarState getCarState() { return null; }
	
	
	// Constructor
	
	public Car() ////
	{
		////
	}
	
	
	// Public setter methods for the 2 views:
	// the main UI view, and the client view
	
	public void setView(ICarView view)
	{
		////
	}
	
	public void setClient(ICarView client)
	{
		////
	}
	
	
	// Private setter methods for gas level and car state
	
	private synchronized void setGasLevel(double gasLevel)
	{
		////
	}
	
	private synchronized void setCarState(CarState state)
	{
		////
	}
	
	
	// User action methods
	// Implementation of ICarModel interface
	
	@Override
	public void startDriving()
	{
		////
	}
	
	@Override
	public void stopDriving()
	{
		////
	}
	
	@Override
	public void startFillingGas()
	{
		////
	}
	
	@Override
	public void stopFillingGas()
	{
		////
	}
	
	
	// Thread method
	// Implementation of Runnable interface
	
	@Override
	public void run()
	{
		////
	}
}
