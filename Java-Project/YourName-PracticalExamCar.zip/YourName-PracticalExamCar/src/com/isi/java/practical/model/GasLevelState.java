package com.isi.java.practical.model;

public enum GasLevelState
{
	Empty, Partial, Full;
}
