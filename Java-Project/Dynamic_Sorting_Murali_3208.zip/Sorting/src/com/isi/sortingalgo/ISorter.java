package com.isi.sortingalgo;

public interface ISorter {

 void sort(int[] array);
}
